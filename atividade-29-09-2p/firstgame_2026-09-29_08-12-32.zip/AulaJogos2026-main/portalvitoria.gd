extends Area2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

var vencido = false

func _on_body_entered(body: Node2D) -> void:
	var cena = get_tree().current_scene
	print(cena.name)
	if body.name == "player1" and vencido == false:
		print("player 1 venceu!")
		vencido = true
	elif body.name == "player2" and vencido == false:
		print("player 2 venceu!")
		vencido = true
	
