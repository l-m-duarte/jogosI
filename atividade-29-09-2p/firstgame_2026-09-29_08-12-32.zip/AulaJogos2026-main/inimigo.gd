extends CharacterBody2D


const SPEED = 300.0
var direction = -10
@onready var batevolta: RayCast2D = $RayCast2D

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	velocity.x = direction * SPEED * delta
	
	if is_on_floor() and velocity.x != 0:
		$animacao.play("caminhar")
	
	if batevolta.is_colliding():
		batevolta.scale.x *= -1
		batevolta.position.x *= -1
		
		direction *= -1
		$animacao.scale.x *= -1
		
	move_and_slide()
